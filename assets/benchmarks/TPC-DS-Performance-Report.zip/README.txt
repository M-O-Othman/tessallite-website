TPC-DS SF1000 Performance Report
- TPC-DS-Performance-Report.pdf : the full report
- data/ : raw measured records (JSON)
    tpcds-sf1000-superset-matrix.json : all 17 business questions, source vs aggregate bytes
    tpcds-sf1000-ab-postfix.json      : gateway A/B run records (route + correctness)
    tpcds-sf1000-bytes-matrix.json    : cache-immune BigQuery dry-run byte matrix
TPC-DS-derived workload; not an official TPC audited result.
